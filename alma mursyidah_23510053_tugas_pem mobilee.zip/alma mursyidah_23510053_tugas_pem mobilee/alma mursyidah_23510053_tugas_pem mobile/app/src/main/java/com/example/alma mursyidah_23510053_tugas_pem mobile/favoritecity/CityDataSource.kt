package com.example.tugas02dheniwibawantobaru.favoritecity

import com.example.tugas02dheniwibawantobaru.R

class CityDataSource {
    fun loadCities(): List<City> {
        return listOf<City>(
            City(1, R.string.tugu, R.drawable.tugu),
            City(2, R.string.comboran, R.drawable.comboran),
            City(3, R.string.ijen, R.drawable.ijen),
            City(4, R.string.matos, R.drawable.matos),
            City(5, R.string.mog, R.drawable.mog),
            City(6, R.string.pasarbesar, R.drawable.pasarbesar),
        )
    }
}