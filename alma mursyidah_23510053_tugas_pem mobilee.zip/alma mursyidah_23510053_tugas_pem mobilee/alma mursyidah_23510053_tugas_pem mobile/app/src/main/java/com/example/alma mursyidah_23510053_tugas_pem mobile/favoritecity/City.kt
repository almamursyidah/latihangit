package com.example.tugas02dheniwibawantobaru.favoritecity

import androidx.annotation.StringRes

data class City(
    val id: Int,
    @StringRes val nameResourceId: Int,
    @StringRes val imageResourceid: Int
)
