package com.alma.crudapi

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class DataItem : Serializable{

    @field:SerializedName("staff_name")
    val staffName: String? = null

    @field:SerializedName("staff_id")
    val staffId: String? = null

    @field:SerializedName("staff_hp")
    val staffHp: String? = null

    @field:SerializedName("staff_alamat")
    val staffAlamat: String? = null
}
data class DataItem(
    val id: String?,
    val name: String?,
    val phone: String?,
    val alamat: String?,
    val pekerjaan: String?,
    val hobi: String?
)
