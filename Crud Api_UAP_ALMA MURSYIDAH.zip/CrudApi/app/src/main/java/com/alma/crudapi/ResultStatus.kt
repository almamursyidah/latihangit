package com.alma.crudapi

class ResultStatus {
    val pesan : String? = null
    val status : Int? = null
}