package com.example.tugas02dheniwibawantobaru.favoritecity

import com.example.tugas02dheniwibawantobaru.R

class CityDataSource {
    fun loadCities(): List<City> {
        return listOf<City>(
            City(1, R.string.tugu, R.drawable.tugu),
            City(2, R.string.comboran, R.drawable.comboran),
            City(3, R.string.ijen, R.drawable.ijen),
            City(4, R.string.matos, R.drawable.matos),
            City(5, R.string.mog, R.drawable.mog),
            City(6, R.string.kayutangan, R.drawable.kayutangan),
            City(7, R.string.pasarbesar, R.drawable.pasarbesar),
            City(8, R.string.cobanjahe, R.drawable.cobanjahe),
            City(9, R.string.cobanrais, R.drawable.cobanrais),
            City(10, R.string.splendid, R.drawable.splendid),
        )
    }
}