package com.example.tugas02dheniwibawantobaru

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.tugas02dheniwibawantobaru.pagerexample.CityTabCarousel
import com.example.tugas02dheniwibawantobaru.ui.theme.Tugas02DheniWibawantoBaruTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Tugas02DheniWibawantoBaruTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CityTabCarousel() // Menampilkan viewpager kamu
                }
            }
        }
    }
}
