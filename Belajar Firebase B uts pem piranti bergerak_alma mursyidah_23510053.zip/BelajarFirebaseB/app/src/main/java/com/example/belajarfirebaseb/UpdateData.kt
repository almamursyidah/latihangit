package com.example.belajarfirebaseb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class UpdateData : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var etNIM: EditText
    private lateinit var etNama: EditText
    private lateinit var etJurusan: EditText
    private lateinit var etJenisKelamin: EditText
    private lateinit var etAlamat: EditText
    private lateinit var btnUpdate: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_data)

        // Inisialisasi
        etNIM = findViewById(R.id.etNIMUpdate)
        etNama = findViewById(R.id.etNamaUpdate)
        etJurusan = findViewById(R.id.etJurusanUpdate)
        etJenisKelamin = findViewById(R.id.etJenisKelaminUpdate)
        etAlamat = findViewById(R.id.etAlamatUpdate)
        btnUpdate = findViewById(R.id.btnUpdate)

        // Inisialisasi Firebase
        database = FirebaseDatabase.getInstance().getReference("Mahasiswa")

        // Menerima data dari activity sebelumnya
        val intent = intent
        val nim = intent.getStringExtra("nim")
        val nama = intent.getStringExtra("nama")
        val jurusan = intent.getStringExtra("jurusan")
        val jenisKelamin = intent.getStringExtra("jenisKelamin")
        val alamat = intent.getStringExtra("alamat")

        // Tampilkan data di form
        etNIM.setText(nim)
        etNama.setText(nama)
        etJurusan.setText(jurusan)
        etJenisKelamin.setText(jenisKelamin)
        etAlamat.setText(alamat)

        // Tombol Update ditekan
        btnUpdate.setOnClickListener {
            val newNim = etNIM.text.toString()
            val newNama = etNama.text.toString()
            val newJurusan = etJurusan.text.toString()
            val newJK = etJenisKelamin.text.toString()
            val newAlamat = etAlamat.text.toString()

            if (newNim.isEmpty() || newNama.isEmpty() || newJurusan.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val updatedData = mapOf(
                "nim" to newNim,
                "nama" to newNama,
                "jurusan" to newJurusan,
                "jenisKelamin" to newJK,
                "alamat" to newAlamat
            )

            // Update ke Firebase
            database.child(newNim).updateChildren(updatedData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Data berhasil diperbarui!", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Gagal memperbarui data!", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
