package com.example.belajarfirebaseb

data class Student(
    var key: String? = null,
    var nim: String? = null,
    var name: String? = null,
    var major: String? = null,
    var gender: String? = null,
    var city: String? = null
)