package com.example.belajarfirebaseb.data_mahasiswa

data class data_mahasiswa(
    var nim: String? = null,
    var nama: String? = null,
    var jurusan: String? = null,
    var jenis_kelamin: String? = null,
    var alamat: String? = null,
    var key: String? = null
)
