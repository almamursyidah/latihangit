package com.example.praktikum02dheniwibawanto.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.praktikum02dheniwibawanto.R

@Composable
fun BiodataForm() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Gambar di atas formulir
        Image(
            painter = painterResource(id = R.drawable.placeholder_image),
            contentDescription = "Gambar Penduduk",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )

        // Nama Lengkap
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text("Nama Lengkap") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        // NIK
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text("NIK") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        // Tempat Lahir
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text("Tempat Lahir") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        // Tanggal Lahir
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text("Tanggal Lahir") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        // Jenis Kelamin
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Text("Jenis Kelamin: ")
            Spacer(modifier = Modifier.width(8.dp))
            RadioButton(
                selected = false,
                onClick = {},
                modifier = Modifier.padding(end = 16.dp)
            )
            Text("Laki-Laki")
            RadioButton(
                selected = false,
                onClick = {},
                modifier = Modifier.padding(end = 16.dp)
            )
            Text("Perempuan")
        }

        // Tombol Submit
        Button(
            onClick = {},
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Text("Kirim Biodata")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewBiodataForm() {
    BiodataForm()
}